import sys
import os
from pathlib import Path
from colorama import init, Fore, Style

# Ініціалізація colorama (потрібно для Windows)
init(autoreset=True)

def print_directory_tree(path, prefix=""):
    """Рекурсивно виводить структуру директорії."""
    entries = sorted(path.iterdir(), key=lambda e: (e.is_file(), e.name))
    
    for i, entry in enumerate(entries):
        connector = "├── " if i < len(entries) - 1 else "└── "
        
        if entry.is_dir():
            # Директорії виводимо синім кольором
            print(prefix + connector + Fore.BLUE + entry.name + "/")
            extension = "│   " if i < len(entries) - 1 else "    "
            print_directory_tree(entry, prefix + extension)
        else:
            # Файли виводимо жовтим кольором
            print(prefix + connector + Fore.YELLOW + entry.name)

def main():
    # Перевірка чи переданий аргумент
    if len(sys.argv) < 2:
        print(Fore.RED + "Помилка: вкажіть шлях до директорії як аргумент.")
        print("Приклад: python hw03.py /шлях/до/директорії")
        sys.exit(1)

    dir_path = Path(sys.argv[1])

    # Перевірка існування та чи це директорія
    if not dir_path.exists():
        print(Fore.RED + f"Помилка: шлях '{dir_path}' не існує.")
        sys.exit(1)

    if not dir_path.is_dir():
        print(Fore.RED + f"Помилка: '{dir_path}' не є директорією.")
        sys.exit(1)

    # Виводимо назву кореневої директорії
    print(Fore.BLUE + str(dir_path.name) + "/")
    print_directory_tree(dir_path)

if __name__ == "__main__":
    main()