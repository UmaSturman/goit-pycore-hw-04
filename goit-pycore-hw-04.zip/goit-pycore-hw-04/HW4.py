# ============================================================
# Бот-асистент для управління контактами (CLI)
# Підтримує команди: hello, add, change, phone, all, close/exit
# ============================================================


def parse_input(user_input):
    """
    Парсер команд: розбиває рядок введення на команду та аргументи.

    Перше слово стає командою (приводиться до нижнього регістру),
    решта слів — списком аргументів *args.

    Приклад:
        "add John 1234567890"  →  cmd="add", args=["John", "1234567890"]
        "hello"                →  cmd="hello", args=[]
    """
    cmd, *args = user_input.split()  # розбиваємо рядок на слова
    cmd = cmd.strip().lower()        # прибираємо зайві пробіли та переводимо в нижній регістр
    return cmd, *args


# ------------------------------------------------------------
# Обробники команд (handlers)
# ------------------------------------------------------------

def add_contact(args, contacts):
    """
    Додає новий контакт до словника contacts.

    Аргументи:
        args     — список [ім'я, номер_телефону]
        contacts — словник {ім'я: номер}

    Якщо контакт з таким ім'ям вже існує — його дані будуть перезаписані.
    """
    name, phone = args          # розпаковуємо аргументи
    contacts[name] = phone      # зберігаємо пару ім'я → телефон у словник
    return "Contact added."


def change_contact(args, contacts):
    """
    Змінює номер телефону для існуючого контакту.

    Аргументи:
        args     — список [ім'я, новий_номер_телефону]
        contacts — словник {ім'я: номер}

    Повертає повідомлення про успіх або помилку, якщо контакт не знайдено.
    """
    name, phone = args          # розпаковуємо аргументи

    if name in contacts:        # перевіряємо чи існує такий контакт
        contacts[name] = phone  # оновлюємо номер телефону
        return "Contact updated."
    else:
        return f"Error: contact '{name}' not found."


def show_phone(args, contacts):
    """
    Повертає номер телефону для вказаного контакту.

    Аргументи:
        args     — список [ім'я]
        contacts — словник {ім'я: номер}

    Повертає номер або повідомлення про помилку, якщо контакт не знайдено.
    """
    name = args[0]              # отримуємо ім'я з аргументів

    if name in contacts:        # перевіряємо наявність контакту
        return contacts[name]   # повертаємо номер телефону
    else:
        return f"Error: contact '{name}' not found."


def show_all(contacts):
    """
    Повертає список усіх збережених контактів у форматі "ім'я: номер".

    Якщо словник порожній — повідомляє про відсутність контактів.
    """
    if not contacts:
        return "No contacts saved."

    result = []
    for name, phone in contacts.items():   # перебираємо всі пари ключ-значення
        result.append(f"{name}: {phone}")  # формуємо рядок для кожного контакту

    return "\n".join(result)               # з'єднуємо всі рядки через перенос


# ------------------------------------------------------------
# Головна функція — цикл запит-відповідь
# ------------------------------------------------------------

def main():
    """
    Точка входу програми. Реалізує нескінченний цикл запит-відповідь (REPL).

    Ініціалізує порожній словник контактів, зчитує команди від користувача
    та викликає відповідні обробники. Завершується при введенні 'close' або 'exit'.
    """
    contacts = {}  # словник для зберігання контактів: {ім'я: номер_телефону}
    print("Welcome to the assistant bot!")

    while True:  # нескінченний цикл — бот працює до команди виходу
        user_input = input("Enter a command: ")

        # ігноруємо порожній ввід
        if not user_input.strip():
            print("Invalid command.")
            continue

        # розбираємо введений рядок на команду та аргументи
        command, *args = parse_input(user_input)

        # --- обробка команд ---

        if command in ["close", "exit"]:
            # завершення роботи бота
            print("Good bye!")
            break

        elif command == "hello":
            # привітання
            print("How can I help you?")

        elif command == "add":
            # додавання нового контакту: add <ім'я> <телефон>
            print(add_contact(args, contacts))

        elif command == "change":
            # зміна існуючого контакту: change <ім'я> <новий_телефон>
            print(change_contact(args, contacts))

        elif command == "phone":
            # показати номер телефону: phone <ім'я>
            print(show_phone(args, contacts))

        elif command == "all":
            # показати всі збережені контакти
            print(show_all(contacts))

        else:
            # будь-яка інша команда вважається невідомою
            print("Invalid command.")


# Запускаємо main() лише якщо файл виконується напряму (не імпортується)
if __name__ == "__main__":
    main()
