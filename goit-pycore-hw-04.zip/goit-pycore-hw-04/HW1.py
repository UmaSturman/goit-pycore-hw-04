def total_salary(path):
    try:
        # Відкриваємо файл для читання з кодуванням utf-8
        with open(path, 'r', encoding='utf-8') as f:
            salaries = []  # Список для зберігання зарплат
            for line in f:
                line = line.strip()  # Прибираємо пробіли та символи переносу рядка
                if ',' in line:  # Перевіряємо чи є кома в рядку
                    parts = line.split(',')  # Розділяємо рядок по комі
                    salaries.append(int(parts[-1].strip()))  # Додаємо зарплату до списку

        # Рахуємо загальну суму зарплат
        total = sum(salaries)
        # Рахуємо середню зарплату, якщо список не порожній
        average = total / len(salaries) if salaries else 0
        return total, average

    except FileNotFoundError:
        # Якщо файл не знайдено - виводимо повідомлення
        print(f"Файл '{path}' не знайдено.")
        return None, None
    except Exception as e:
        # Обробка інших можливих помилок
        print(f"Помилка: {e}")
        return None, None


# Викликаємо функцію та передаємо шлях до файлу
total, average = total_salary("salary_file.txt")
# Виводимо результат
print(f"Загальна сума заробітної плати: {total}, Середня заробітна плата: {average}")